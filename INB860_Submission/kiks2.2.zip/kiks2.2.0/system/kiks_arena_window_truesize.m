% -----------------------------------------------------
%  (c) 2000-2004 Theodor Storm <theodor@tstorm.se>
%  http://www.tstorm.se
% -----------------------------------------------------

function kiks_arena_window_truesize
global KIKS_ARENA_HDL

truesize(KIKS_ARENA_HDL);