function kiks_gui_placerobot
global KIKS_RBTARRAY KIKS_GUI_HDL

kiks_spawn_robot;

